package com.example.constraintlayouts

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat
import android.view.View


class MainActivity : AppCompatActivity() {

    private lateinit var textViewRed: TextView
    private lateinit var changeColorButtonRed: Button

    private lateinit var textViewYellow: TextView
    private lateinit var changeColorButtonYellow: Button

    private lateinit var textViewGreen: TextView
    private lateinit var changeColorButtonGreen: Button

    private lateinit var boxThree: TextView
    private lateinit var boxFour: TextView
    private lateinit var boxFive: TextView


    @SuppressLint("CutPasteId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        boxThree = findViewById(R.id.boxThree)
        boxThree.setOnClickListener {
            val color = ContextCompat.getColor(this, R.color.colorGreen)
            boxThree.setBackgroundColor(color)
        }

        boxFour = findViewById(R.id.boxFour)
        boxFour.setOnClickListener {
            val color = ContextCompat.getColor(this, R.color.colorGreen)
            boxFour.setBackgroundColor(color)
        }

        boxFive = findViewById(R.id.boxFive)
        boxFive.setOnClickListener {
            val color = ContextCompat.getColor(this, R.color.colorGreen)
            boxFive.setBackgroundColor(color)
        }

        textViewRed = findViewById(R.id.boxThree)
        changeColorButtonRed = findViewById(R.id.button1)

        changeColorButtonRed.setOnClickListener {
            val colorR = ContextCompat.getColor(this, R.color.colorRed)
            textViewRed.setBackgroundColor(colorR)
        }

        textViewYellow = findViewById(R.id.boxFour)
        changeColorButtonYellow = findViewById(R.id.button2)

        changeColorButtonYellow.setOnClickListener {
            val colorY = ContextCompat.getColor(this, R.color.colorYellow)
            textViewYellow.setBackgroundColor(colorY)
        }

        textViewGreen = findViewById(R.id.boxFive)
        changeColorButtonGreen = findViewById(R.id.button3)

        changeColorButtonGreen.setOnClickListener {
            val colorG = ContextCompat.getColor(this, R.color.colorGreen)
            textViewGreen.setBackgroundColor(colorG)
        }
    }
}